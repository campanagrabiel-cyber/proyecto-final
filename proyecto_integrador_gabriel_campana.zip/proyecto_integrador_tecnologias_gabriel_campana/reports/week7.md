# Semana 7: Integración y validación

**Autor:** Gabriel Campaña  
**Fecha:** 2025-08-26

## Objetivo de la semana
Integrar módulos, validar entradas/salidas, refactorizar y documentar en README.

## Desarrollo
Integrar módulos, validar entradas/salidas, refactorizar y documentar en README.

## Evidencias
- Borradores o notas en `reports/`
- Código relacionado en `src/`
- Dataset actualizado en `data/`

## Conclusiones
- Aprendizaje clave: ...  
- Próximos pasos: ...
