# Semana 5: Visualización de datos

**Autor:** Gabriel Campaña  
**Fecha:** 2025-08-26

## Objetivo de la semana
Construir visualizaciones con matplotlib a partir del dataset `tech_trends.csv`.

## Desarrollo
Construir visualizaciones con matplotlib a partir del dataset `tech_trends.csv`.

## Evidencias
- Borradores o notas en `reports/`
- Código relacionado en `src/`
- Dataset actualizado en `data/`

## Conclusiones
- Aprendizaje clave: ...  
- Próximos pasos: ...
