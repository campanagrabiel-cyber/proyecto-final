# Semana 3: Ética, riesgos y regulación

**Autor:** Gabriel Campaña  
**Fecha:** 2025-08-26

## Objetivo de la semana
Identificar riesgos (privacidad, sesgos, desinformación), principios éticos y marcos regulatorios (RGPD/estándares locales).

## Desarrollo
Identificar riesgos (privacidad, sesgos, desinformación), principios éticos y marcos regulatorios (RGPD/estándares locales).

## Evidencias
- Borradores o notas en `reports/`
- Código relacionado en `src/`
- Dataset actualizado en `data/`

## Conclusiones
- Aprendizaje clave: ...  
- Próximos pasos: ...
