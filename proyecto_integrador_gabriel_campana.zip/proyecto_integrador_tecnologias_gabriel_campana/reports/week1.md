# Semana 1: Introducción y selección de tecnologías

**Autor:** Gabriel Campaña  
**Fecha:** 2025-08-26

## Objetivo de la semana
Definir tecnologías emergentes a estudiar (IA, IoT, Big Data, Blockchain, RA/RV) y justificar su relevancia.

## Desarrollo
Definir tecnologías emergentes a estudiar (IA, IoT, Big Data, Blockchain, RA/RV) y justificar su relevancia.

## Evidencias
- Borradores o notas en `reports/`
- Código relacionado en `src/`
- Dataset actualizado en `data/`

## Conclusiones
- Aprendizaje clave: ...  
- Próximos pasos: ...
