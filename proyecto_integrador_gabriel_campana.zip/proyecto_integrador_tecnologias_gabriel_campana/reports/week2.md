# Semana 2: Impacto social por sector

**Autor:** Gabriel Campaña  
**Fecha:** 2025-08-26

## Objetivo de la semana
Analizar el impacto social en educación, salud, economía y comunicación, con ejemplos concretos y fuentes confiables.

## Desarrollo
Analizar el impacto social en educación, salud, economía y comunicación, con ejemplos concretos y fuentes confiables.

## Evidencias
- Borradores o notas en `reports/`
- Código relacionado en `src/`
- Dataset actualizado en `data/`

## Conclusiones
- Aprendizaje clave: ...  
- Próximos pasos: ...
