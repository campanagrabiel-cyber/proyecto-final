# Semana 6: IA y proyección de tendencias

**Autor:** Gabriel Campaña  
**Fecha:** 2025-08-26

## Objetivo de la semana
Crear una proyección simple por tecnología que anticipe tendencias para los próximos 1–3 años.

## Desarrollo
Crear una proyección simple por tecnología que anticipe tendencias para los próximos 1–3 años.

## Evidencias
- Borradores o notas en `reports/`
- Código relacionado en `src/`
- Dataset actualizado en `data/`

## Conclusiones
- Aprendizaje clave: ...  
- Próximos pasos: ...
